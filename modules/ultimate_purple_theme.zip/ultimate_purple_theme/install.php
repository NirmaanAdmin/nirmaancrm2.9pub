<?php
defined('BASEPATH') or exit('No direct script access allowed');
$CI = &get_instance();
add_option('ultimate_purple_theme_customers', 1);